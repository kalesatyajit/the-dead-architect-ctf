# Architect notes

The notebook is intentionally incomplete.
